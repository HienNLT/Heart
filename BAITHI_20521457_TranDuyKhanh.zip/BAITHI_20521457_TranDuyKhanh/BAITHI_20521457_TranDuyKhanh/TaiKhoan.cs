﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAITHI_20521457_TranDuyKhanh
{
    class TaiKhoan
    {
        public string tenKH;       
        public string diaChi;
        public string ngheN;
        public int soLV;
        public double donGia;
        public double thanhTien;
        public double thueVAT;
        public double giamGia;
        
        public TaiKhoan()
        {

        }
        public TaiKhoan(string ten, string dc, string nghe,int slv, double dg,double tt, double tv,double gg)
        {
            this.tenKH = ten;
            diaChi = dc;
            ngheN = nghe;
           soLV = slv;
           donGia = dg;
            thanhTien = tt;
            thueVAT = tv;
            this.giamGia = gg;          
            
        }

        public string tenKH1 {  get => tenKH; set => tenKH = value; }

        public string diaChi1 { get => diaChi; set => diaChi = value; }
        public string ngheN1 { get => ngheN; set => ngheN = value; }
        public int soLV1 { get => soLV; set => soLV = value; }
        public double donGia1 { get => donGia; set => donGia = value; }
        public double thanhTien1 { get => thanhTien; set => thanhTien = value; }
        public double thueVAT1 { get => thueVAT; set => thueVAT = value; }
        public double giamGia1 { get => giamGia; set => giamGia = value; }
        
       
    }
}
