﻿namespace BAITHI_20521457_TranDuyKhanh
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTong = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnThemSua = new System.Windows.Forms.Button();
            this.txtSLV = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TXTDC = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtKH = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rdSV = new System.Windows.Forms.RadioButton();
            this.rdK = new System.Windows.Forms.RadioButton();
            this.txtDONGIA = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTT = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtVAT = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtGG = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnSTT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnTENKH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDIACHI = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnNGHE = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnSLV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDG = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnTT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnVAT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnGIAMGIA = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // txtTong
            // 
            this.txtTong.Location = new System.Drawing.Point(642, 581);
            this.txtTong.Name = "txtTong";
            this.txtTong.Size = new System.Drawing.Size(253, 22);
            this.txtTong.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(549, 581);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 19);
            this.label6.TabIndex = 27;
            this.label6.Text = "Tổng tiền:";
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(594, 288);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(133, 36);
            this.btnThoat.TabIndex = 26;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnThemSua
            // 
            this.btnThemSua.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnThemSua.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemSua.Location = new System.Drawing.Point(272, 288);
            this.btnThemSua.Name = "btnThemSua";
            this.btnThemSua.Size = new System.Drawing.Size(133, 36);
            this.btnThemSua.TabIndex = 25;
            this.btnThemSua.Text = "Thêm/Cập nhật";
            this.btnThemSua.UseVisualStyleBackColor = true;
            this.btnThemSua.Click += new System.EventHandler(this.btnThemSua_Click);
            // 
            // txtSLV
            // 
            this.txtSLV.Location = new System.Drawing.Point(226, 176);
            this.txtSLV.Name = "txtSLV";
            this.txtSLV.Size = new System.Drawing.Size(239, 22);
            this.txtSLV.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(91, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 19);
            this.label5.TabIndex = 23;
            this.label5.Text = "So luong ve";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(57, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 19);
            this.label4.TabIndex = 21;
            this.label4.Text = "Địa chỉ khách hàng:";
            // 
            // TXTDC
            // 
            this.TXTDC.Location = new System.Drawing.Point(226, 82);
            this.TXTDC.Name = "TXTDC";
            this.TXTDC.Size = new System.Drawing.Size(248, 22);
            this.TXTDC.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(91, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 19);
            this.label3.TabIndex = 19;
            this.label3.Text = "Nghe nghiep";
            // 
            // txtKH
            // 
            this.txtKH.Location = new System.Drawing.Point(235, 33);
            this.txtKH.Name = "txtKH";
            this.txtKH.Size = new System.Drawing.Size(239, 22);
            this.txtKH.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(91, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 19);
            this.label2.TabIndex = 17;
            this.label2.Text = "Ten khach hang";
            // 
            // rdSV
            // 
            this.rdSV.AutoSize = true;
            this.rdSV.Location = new System.Drawing.Point(226, 132);
            this.rdSV.Name = "rdSV";
            this.rdSV.Size = new System.Drawing.Size(82, 20);
            this.rdSV.TabIndex = 30;
            this.rdSV.TabStop = true;
            this.rdSV.Text = "Sinh vien";
            this.rdSV.UseVisualStyleBackColor = true;
            // 
            // rdK
            // 
            this.rdK.AutoSize = true;
            this.rdK.Location = new System.Drawing.Point(393, 131);
            this.rdK.Name = "rdK";
            this.rdK.Size = new System.Drawing.Size(58, 20);
            this.rdK.TabIndex = 31;
            this.rdK.TabStop = true;
            this.rdK.Text = "Khac";
            this.rdK.UseVisualStyleBackColor = true;
            // 
            // txtDONGIA
            // 
            this.txtDONGIA.Location = new System.Drawing.Point(226, 234);
            this.txtDONGIA.Name = "txtDONGIA";
            this.txtDONGIA.Size = new System.Drawing.Size(239, 22);
            this.txtDONGIA.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(91, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 19);
            this.label1.TabIndex = 32;
            this.label1.Text = "Don gia";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtTT
            // 
            this.txtTT.Enabled = false;
            this.txtTT.Location = new System.Drawing.Point(656, 33);
            this.txtTT.Name = "txtTT";
            this.txtTT.Size = new System.Drawing.Size(239, 22);
            this.txtTT.TabIndex = 35;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(521, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 19);
            this.label7.TabIndex = 34;
            this.label7.Text = "Thanh tien";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtVAT
            // 
            this.txtVAT.Enabled = false;
            this.txtVAT.Location = new System.Drawing.Point(656, 82);
            this.txtVAT.Name = "txtVAT";
            this.txtVAT.Size = new System.Drawing.Size(239, 22);
            this.txtVAT.TabIndex = 37;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(521, 85);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 19);
            this.label8.TabIndex = 36;
            this.label8.Text = "Thue VAT";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtGG
            // 
            this.txtGG.Enabled = false;
            this.txtGG.Location = new System.Drawing.Point(656, 179);
            this.txtGG.Name = "txtGG";
            this.txtGG.Size = new System.Drawing.Size(239, 22);
            this.txtGG.TabIndex = 39;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(525, 179);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 19);
            this.label9.TabIndex = 38;
            this.label9.Text = "Giam Gia";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnSTT,
            this.columnTENKH,
            this.columnDIACHI,
            this.columnNGHE,
            this.columnSLV,
            this.columnDG,
            this.columnTT,
            this.columnVAT,
            this.columnGIAMGIA});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(-7, 336);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1320, 242);
            this.listView1.TabIndex = 40;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged_1);
            // 
            // columnSTT
            // 
            this.columnSTT.Text = "STT";
            this.columnSTT.Width = 104;
            // 
            // columnTENKH
            // 
            this.columnTENKH.Text = "Ten Khach hang";
            this.columnTENKH.Width = 185;
            // 
            // columnDIACHI
            // 
            this.columnDIACHI.Text = "Địa chỉ";
            this.columnDIACHI.Width = 160;
            // 
            // columnNGHE
            // 
            this.columnNGHE.Text = "Nghe Nghiep";
            this.columnNGHE.Width = 196;
            // 
            // columnSLV
            // 
            this.columnSLV.Text = "So Luong Ve";
            this.columnSLV.Width = 160;
            // 
            // columnDG
            // 
            this.columnDG.Text = "Don Gia";
            this.columnDG.Width = 160;
            // 
            // columnTT
            // 
            this.columnTT.Text = "Thanh Tien";
            this.columnTT.Width = 160;
            // 
            // columnVAT
            // 
            this.columnVAT.Text = "Thue VAT";
            this.columnVAT.Width = 160;
            // 
            // columnGIAMGIA
            // 
            this.columnGIAMGIA.Text = "Giam Gia";
            this.columnGIAMGIA.Width = 160;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1317, 650);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.txtGG);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtVAT);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtTT);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtDONGIA);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rdK);
            this.Controls.Add(this.rdSV);
            this.Controls.Add(this.txtTong);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnThemSua);
            this.Controls.Add(this.txtSLV);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TXTDC);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtKH);
            this.Controls.Add(this.label2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtTong;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnThemSua;
        private System.Windows.Forms.TextBox txtSLV;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TXTDC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtKH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rdSV;
        private System.Windows.Forms.RadioButton rdK;
        private System.Windows.Forms.TextBox txtDONGIA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTT;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtVAT;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtGG;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnSTT;
        private System.Windows.Forms.ColumnHeader columnTENKH;
        private System.Windows.Forms.ColumnHeader columnDIACHI;
        private System.Windows.Forms.ColumnHeader columnNGHE;
        private System.Windows.Forms.ColumnHeader columnSLV;
        private System.Windows.Forms.ColumnHeader columnDG;
        private System.Windows.Forms.ColumnHeader columnTT;
        private System.Windows.Forms.ColumnHeader columnVAT;
        private System.Windows.Forms.ColumnHeader columnGIAMGIA;
    }
}

