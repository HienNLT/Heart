﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace BAITHI_20521457_TranDuyKhanh
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private Dictionary<string, TaiKhoan> dstk;

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnThemSua_Click(object sender, EventArgs e)
        {
            if (txtKH.Text == "" || TXTDC.Text == "" || txtDONGIA.Text == "")
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            TaiKhoan tk = new TaiKhoan();
            tk.tenKH = txtKH.Text;
                tk.diaChi = TXTDC.Text;
                tk.soLV = int.Parse(txtSLV.Text);
                tk.donGia = double.Parse(txtDONGIA.Text);
                tk.thueVAT = 0.1 ;
                if (rdSV.Checked == true)
                {
                    tk.ngheN = rdSV.Text;
                    tk.giamGia = 0.1;
                }
                else if (rdK.Checked == true)
                {
                    tk.ngheN = rdK.Text;
                    tk.giamGia = 0.05;
                }

                tk.thanhTien = int.Parse(txtSLV.Text) * double.Parse(txtDONGIA.Text);
                dstk.Add(tk.tenKH, tk);
                hienThiDSKhachHang();
                MessageBox.Show("Thêm mới dữ liệu thành công!");
            txtKH.Text = " ";
            TXTDC.Text = " ";
            txtDONGIA.Text = " ";
            txtSLV.Text = " ";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dstk = new Dictionary<string, TaiKhoan>();
        }
        private void hienThiDSKhachHang()
        {
            

            int i = 1;
            double tongtien = 0;
            listView1.Items.Clear();
            foreach (KeyValuePair<string, TaiKhoan> kh in dstk)
            {
                ListViewItem lvi = new ListViewItem(i + "");
                lvi.SubItems.Add(kh.Value.tenKH);                
                lvi.SubItems.Add(kh.Value.diaChi);
                lvi.SubItems.Add(kh.Value.ngheN);
                lvi.SubItems.Add(kh.Value.soLV + "");
                lvi.SubItems.Add(kh.Value.donGia + "");
                lvi.SubItems.Add(kh.Value.thanhTien + "");
                lvi.SubItems.Add(kh.Value.thueVAT + "");
                lvi.SubItems.Add(kh.Value.giamGia + "");
                
                tongtien += kh.Value.thanhTien + kh.Value.thanhTien* kh.Value.thueVAT - kh.Value.thanhTien* kh.Value.giamGia;
                listView1.Items.Add(lvi);
                i++;
            }
            txtTong.Text = tongtien + "";
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Thoát chương trình ?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (ret == DialogResult.Yes)
            {
                Close();
            }
        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
        }
    }
}
